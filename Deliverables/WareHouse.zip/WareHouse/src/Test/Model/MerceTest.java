package Test.Model;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.sql.SQLException;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import bean.MerceBean;
import operations.Merce;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MerceTest {
	private MerceBean oggettoMerce = null; //oggetto che voglio inserire
    private Merce managerMerce = new Merce();  //manager che usa le funzioni per gestire gli oggetti
	
    @Test
    @Order(1)
	/*inserimento nuova merce*/
	void TC_InsertMerce() throws SQLException	
	{
    	oggettoMerce = new MerceBean();		
    	oggettoMerce.setCodiceMerce("iphXS MAX");
    	oggettoMerce.setTitolo("Iphone XS MAX");
    	oggettoMerce.setCategoria("SmartphoneX");
    	oggettoMerce.setMarca("AppleX");
    	oggettoMerce.setDescrizione("Telefono");
    	oggettoMerce.setCosto(1200); 
    	managerMerce.insertNewMerce(oggettoMerce);
		assertNotNull(managerMerce.searchMerceByCodiceMerce(oggettoMerce.getCodiceMerce()));		
	}
	
    @Test
    @Order(2)
    /*ricerca merce*/
	void TC_SearchMerce() throws SQLException	
	{
		assertNotNull(managerMerce.searchMerceByCodiceMerce("iphXS MAX"));	
	}
	
    @Test
    @Order(3)
	/*cancella nuova merce*/
	void TC_DeleteMerce() throws SQLException	
	{
    	oggettoMerce = new MerceBean();		
    	oggettoMerce.setCodiceMerce("iphXS MAX");    	
    	assertNotNull(managerMerce.searchMerceByCodiceMerce(oggettoMerce.getCodiceMerce()));
    	managerMerce.deleteMerce(oggettoMerce.getCodiceMerce());		
	}
}

