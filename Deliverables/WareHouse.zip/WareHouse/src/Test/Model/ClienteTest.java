package Test.Model;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.sql.SQLException;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import bean.UserBean;
import operations.Cliente;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ClienteTest {
	private UserBean u = null;
    private Cliente cliente = new Cliente();
	
    //Ogni funzione deve essere atomica ed indipendente
    
    @Test
    @Order(1)
	/*inserimento nuovo utente*/
	void TC_InsertUtente() throws SQLException	
	{
		u = new UserBean();		
		u.setCfUtente("CHRVCN81HL8452C");
		u.setNome("Vincenzo");
		u.setCognome("Chierchia");
		u.setEmail("v.chierchia@live.it");
		cliente.insertUser(u);
		assertNotNull(cliente.searchUser("v.chierchia@live.it"));				
	}
	
    @Test
    @Order(2)
    /*ricerca utente*/
	void TC_SearchUser() throws SQLException	
	{    	
		assertNotNull(cliente.searchUserByCF("CHRVCN81HL8452C"));	
	}
	
    @Test
    @Order(3)
	/*inserimento nuovo utente*/
	void TC_DeleteUtente() throws SQLException	
	{
		u = new UserBean();		
		u.setCfUtente("CHRVCN81HL8452C");		
		cliente.deleteUser(u.getCfUtente()); //cancello 
		assertNull(cliente.searchUserByCF(u.getCfUtente())); //cerco	
	}
}