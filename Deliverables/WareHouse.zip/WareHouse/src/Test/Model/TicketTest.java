package Test.Model;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.SQLException;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import bean.TicketBean;
import operations.Ticket;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TicketTest {
	
	
	private TicketBean oggettoTicket = null; //oggetto che voglio inserire
    private Ticket managerTicket = new Ticket();  //manager che usa le funzioni

    @Test
    @Order(1)
	/*inserimento nuovo Ticket*/
	void TC_insertNewticket() throws SQLException	
	{
    	oggettoTicket = new TicketBean();		
    	oggettoTicket.setCodiceTicket(22333);
    	oggettoTicket.setTitolo("ip X2");
    	oggettoTicket.setDescrizione("Telefono guasto");
    	oggettoTicket.setStato("Spedito");
    	oggettoTicket.setCodiceFiscale("MMNA31P129GP98");
    	oggettoTicket.setCodiceOrdine(543201); 
    	String CodiceTicket = String.valueOf(oggettoTicket.getCodiceTicket());
    	managerTicket.insertNewticket(oggettoTicket);
    	
		assertNotNull(managerTicket.searchTicketByCodiceTicket(CodiceTicket));		
	}
    
    @Test
    @Order(2)
    /*ricerca ticket*/
	void TC_SearchTicket() throws SQLException	
	{    
    	String CodiceTicket = String.valueOf(22333);
		assertNotNull(managerTicket.searchTicketByCodiceTicket(CodiceTicket));	
	}
    
    @Test
    @Order(3)
	/*cancella ticket*/
	void TC_closeTicket() throws SQLException	
	{
    	oggettoTicket = new TicketBean();		
    	oggettoTicket.setCodiceTicket(22333);    	
    	String codiceticket = String.valueOf(22333);
    	assertNotNull(managerTicket.searchTicketByCodiceTicket(codiceticket));
    	managerTicket.closeTicket((codiceticket));		    
	}
	
    
}
