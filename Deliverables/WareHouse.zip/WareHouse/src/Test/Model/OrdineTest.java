package Test.Model;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.sql.SQLException;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import bean.OrderBean;
import bean.UserBean;
import operations.Cliente;
import operations.OrdineCliente;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class OrdineTest {
	private UserBean u = null;
	private OrderBean oggettoOrdine = null; //oggetto che voglio inserire
    private OrdineCliente managerOrdine = new OrdineCliente();  //manager che usa le funzioni per gestire gli oggetti
    private Cliente cliente = new Cliente();
    
    @Test
    @Order(1)
	/*inserimento nuovo ordine*/
	void TC_InsertOrdine() throws SQLException	
	{
    	oggettoOrdine = new OrderBean();	
    	u = cliente.searchUser("eduardo.chierchia@gmail.com"); 
    	oggettoOrdine.setCitta("ROMA");
    	oggettoOrdine.setDataOrdine("2021-10-19");
    	oggettoOrdine.setVia("Via ini");
    	oggettoOrdine.setCivico(11);
    	oggettoOrdine.setCap(80043);
    	oggettoOrdine.setStato("Spedito");
    	oggettoOrdine.setCodiceOrdine(553222); 
    	oggettoOrdine.setnMerci(10); 
    	oggettoOrdine.setTotale(150); 
    	oggettoOrdine.setMetodoDiPagamento("visa");
    	oggettoOrdine.setNumCard("12345678910");
    	oggettoOrdine.setCfCliente("CHRDRD81H15L845C");  
    	managerOrdine.insertNewOrder(oggettoOrdine, u);        
		assertNotNull(managerOrdine.searchByCodeOrder(oggettoOrdine.getCodiceOrdine()));			
	}
    
    @Test
    @Order(2)
    /*ricerca ordine*/
	void TC_SearchOrdine() throws SQLException	
	{
		assertNotNull(managerOrdine.searchByCodeOrder(553222));	
	}
	
    @Test
    @Order(3)
	/*cancella ordine*/
	void TC_deleteOrder() throws SQLException	
	{    	
    	oggettoOrdine = new OrderBean();	
    	oggettoOrdine.setCodiceOrdine(553222);     	
		managerOrdine.deleteOrder(oggettoOrdine.getCodiceOrdine());		
		assertNull(managerOrdine.searchByCodeOrder(oggettoOrdine.getCodiceOrdine()));
	}

}
