package Test.Controller;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mockito;

import bean.MerceBean;
import operations.Merce;
import servlet.MerceOperations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MerceServletTest {
	
	private HttpServletRequest mockedRequest;
    private HttpServletResponse mockedResponse;
    private HttpSession mockedSession;
    private RequestDispatcher mockedDispatcher;

    private MerceBean oggettoMerce = null; //oggetto che voglio inserire
    private Merce managerMerce = null;  //manager che usa le funzioni per gestire gli oggetti
    private MerceOperations servlet = null;
    
    @BeforeAll
	 void setUp() throws SQLException
	 {
	  servlet = new MerceOperations();
	  mockedRequest= Mockito.mock(HttpServletRequest.class);
	  mockedResponse= Mockito.mock(HttpServletResponse.class);
	  mockedSession = Mockito.mock(HttpSession.class);
	  mockedDispatcher = Mockito.mock(RequestDispatcher.class);
	  	 
	  managerMerce = new Merce();	  
	  oggettoMerce = managerMerce.searchMerceByCodiceMerce("iphX");	 
	  
	  /*Gestione mock della sessione*/
	  Mockito.when(mockedRequest.getSession()).thenReturn(mockedSession);
    }
    
    @Test
    @Order(1)
    void TC_ADDTOCART_1() throws IOException, ServletException
    {	    	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("addToCart");
        this.TC_sub1();
    }
    
    @Test
    @Order(2)
    void TC_EMPTYCART_1() throws  IOException, ServletException
    {	    	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("emptyCart");
        this.TC_sub1();
    }
    
    @Test
    @Order(3)
    void TC_DELETEFROMCART_1() throws IOException, ServletException
    {	
    	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("deleteFromCart");
        this.TC_sub1();
    }
    
    void TC_sub1() throws ServletException, IOException
    {
    	Mockito.when(mockedRequest.getParameter("codiceMerce")).thenReturn("iphXS");
        Mockito.when(mockedRequest.getParameter("titolo")).thenReturn("Iphone XS");
        Mockito.when(mockedRequest.getParameter("categoria")).thenReturn("SmartphoneX");
        Mockito.when(mockedRequest.getParameter("marca")).thenReturn("AppleX");
        //Mockito.when(mockedRequest.getParameter("immagine")).thenReturn(oggettoMerce.getImmagine());
        String costo = String.valueOf(1000);
        Mockito.when(mockedRequest.getParameter("costo")).thenReturn(costo);
        
        Mockito.when(mockedRequest.getRequestDispatcher(Mockito.anyString())).thenReturn(mockedDispatcher);
        servlet.doGet(mockedRequest,mockedResponse);
    }
    
    @AfterAll
    void tearDown()
    {
        mockedRequest=null;
        mockedResponse=null;
        servlet=null;
        mockedSession=null;
        mockedDispatcher=null;
    }
}
