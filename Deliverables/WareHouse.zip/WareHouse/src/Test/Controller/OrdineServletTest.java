package Test.Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mockito;

import bean.CartBean;
import bean.OrderBean;
import operations.OrdineCliente;
import servlet.OrdersOperations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class OrdineServletTest {
	
	private HttpServletRequest mockedRequest;
    private HttpServletResponse mockedResponse;
    private HttpSession mockedSession;
    private RequestDispatcher mockedDispatcher;
    
    //private UserBean u = null;
	private OrderBean oggettoOrdine = null; //oggetto che voglio inserire
    private OrdineCliente managerOrdine = null;  //manager che usa le funzioni per gestire gli oggetti
    private OrdersOperations servlet = null;
    
    @BeforeAll
  	 void setUp() throws SQLException
  	 {
  	  servlet = new OrdersOperations();
  	  mockedRequest= Mockito.mock(HttpServletRequest.class);
  	  mockedResponse= Mockito.mock(HttpServletResponse.class);
  	  mockedSession = Mockito.mock(HttpSession.class);
  	  mockedDispatcher = Mockito.mock(RequestDispatcher.class);
  	  	 
  	  managerOrdine = new OrdineCliente();	  
  	  oggettoOrdine = managerOrdine.searchByCodeOrder(54320);	 
  	  
  	  /*Gestione mock della sessione*/
  	  Mockito.when(mockedRequest.getSession()).thenReturn(mockedSession);
      }
    
    @Test
    @Order(1)
    void TC_ADDTOCART_1() throws IOException, ServletException
    {	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("insertNewOrder");
        this.TC_sub2();
    }
    @Test
    @Order(2)
    void TC_SEARCH_1() throws IOException, ServletException
    {	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("searchByUser");
        this.TC_sub2();
    }
    
    @Test
    @Order(2)
    void TC_DELETE_1() throws IOException, ServletException
    {	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("cancelByID");
        this.TC_sub2();
    }
    
    
    void TC_sub2() throws ServletException, IOException
    {   
    	 
    	 Mockito.when(mockedRequest.getSession().getAttribute("cart")).thenReturn(new CartBean());
    	 Mockito.when(mockedRequest.getSession().getAttribute("userlog")).thenReturn(Boolean.TRUE);
     	
    	String codiceOrdine = String.valueOf(553201);
    	Mockito.when(mockedRequest.getParameter("codiceOrdine")).thenReturn(codiceOrdine);
    	
        Mockito.when(mockedRequest.getParameter("dataOrdine")).thenReturn(oggettoOrdine.getDataOrdine());
        Mockito.when(mockedRequest.getParameter("via")).thenReturn("Via Pini");
        String civico = String.valueOf(11);
        Mockito.when(mockedRequest.getParameter("civico")).thenReturn(civico);
        String nMerci = String.valueOf(10);
        Mockito.when(mockedRequest.getParameter("nMerci")).thenReturn(nMerci);
        Mockito.when(mockedRequest.getParameter("cfCliente")).thenReturn("GRGBLE63M66C140G");
        Mockito.when(mockedRequest.getParameter("MetodoDiPagamento")).thenReturn("visa");
        Mockito.when(mockedRequest.getParameter("NumCard")).thenReturn("50345678910");
        Mockito.when(mockedRequest.getParameter("Stato")).thenReturn("Spedito");
        
       
        
        Mockito.when(mockedRequest.getRequestDispatcher(Mockito.anyString())).thenReturn(mockedDispatcher);
        servlet.doGet(mockedRequest,mockedResponse);
    }
    
    @AfterAll
    void tearDown()
    {
        mockedRequest=null;
        mockedResponse=null;
        servlet=null;
        mockedSession=null;
        mockedDispatcher=null;
    }

}
