package Test.Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mockito;

import bean.TicketBean;
import bean.UserBean;
import operations.Ticket;
import servlet.TicketOperations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TicketServletTest {
	
	private HttpServletRequest mockedRequest;
    private HttpServletResponse mockedResponse;
    private HttpSession mockedSession;
    private RequestDispatcher mockedDispatcher;
    
    //private UserBean u = null;
	private TicketBean oggettoTicket = null; //oggetto che voglio inserire
    private Ticket managerTicket = null;  //manager che usa le funzioni per gestire gli oggetti
    private TicketOperations servlet = null;

    @BeforeAll
 	 void setUp() throws SQLException
 	 {
 	  servlet = new TicketOperations();
 	  mockedRequest= Mockito.mock(HttpServletRequest.class);
 	  mockedResponse= Mockito.mock(HttpServletResponse.class);
 	  mockedSession = Mockito.mock(HttpSession.class);
 	  mockedDispatcher = Mockito.mock(RequestDispatcher.class);
 	  	 
 	  managerTicket = new Ticket();	  
 	  oggettoTicket = managerTicket.searchTicketByCodiceTicket("22333");	 
 	  
 	  /*Gestione mock della sessione*/
 	  Mockito.when(mockedRequest.getSession()).thenReturn(mockedSession);
     }
    
    @Test
    @Order(1)
    void TC_INSERT_1() throws IOException, ServletException
    {	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("insert");
        this.TC_sub2();
    }
    @Test
    @Order(2)
    void TC_SEARCH_1() throws IOException, ServletException
    {	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("searchOpenTicketsByUser");
        this.TC_sub2();
    }
    
    @Test
    @Order(2)
    void TC_DELETE_1() throws IOException, ServletException
    {	
    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("searchClosedTicketsByUser");
        this.TC_sub2();
    }
    
    
    void TC_sub2() throws ServletException, IOException
    {   
    	String codiceticket = String.valueOf(22333);
    	Mockito.when(mockedRequest.getSession().getAttribute("user")).thenReturn(new UserBean());
    	Mockito.when(mockedRequest.getParameter("codice")).thenReturn(codiceticket);    	    	
        Mockito.when(mockedRequest.getParameter("Titolo")).thenReturn("ip XS MAX");
        Mockito.when(mockedRequest.getParameter("Descrizione")).thenReturn("Telefono guasto");
        Mockito.when(mockedRequest.getParameter("Stato")).thenReturn(oggettoTicket.getStato());
        Mockito.when(mockedRequest.getParameter("CodiceFiscale")).thenReturn("GRGB66G31M129G");
        String CodiceOrdine = String.valueOf(55);
        Mockito.when(mockedRequest.getParameter("CodiceOrdine")).thenReturn(CodiceOrdine);
        Mockito.when(mockedRequest.getRequestDispatcher("index.html")).thenReturn(mockedDispatcher);
        Mockito.when(mockedRequest.getSession().getAttribute("userlog")).thenReturn(Boolean.TRUE);
        servlet.doGet(mockedRequest,mockedResponse);
    }
    
    @AfterAll
    void tearDown()
    {
        mockedRequest=null;
        mockedResponse=null;
        servlet=null;
        mockedSession=null;
        mockedDispatcher=null;
    }

}
