package Test.Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockito.Mockito;

import bean.UserBean;
import operations.Cliente;
import servlet.UsersOperations;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ClienteServletTest {
	private HttpServletRequest mockedRequest;
    private HttpServletResponse mockedResponse;
    private HttpSession mockedSession;
    private RequestDispatcher mockedDispatcher;
    
    private UserBean u = null;
    private Cliente cliente = null;
        
	private UsersOperations servlet = null;
	
	 @BeforeAll
	 void setUp() throws SQLException
	 {
	  servlet = new UsersOperations();
	  mockedRequest= Mockito.mock(HttpServletRequest.class);
	  mockedResponse= Mockito.mock(HttpServletResponse.class);
	  mockedSession = Mockito.mock(HttpSession.class);
	  mockedDispatcher = Mockito.mock(RequestDispatcher.class);
	  	 
	  cliente = new Cliente();	  
	  
	  
	  /*Gestione mock della sessione*/
	  Mockito.when(mockedRequest.getSession()).thenReturn(mockedSession);
     }
	 
	//
	    @Test
	    @Order(1)
	    void TC_LOGIN_1() throws IOException, ServletException
	    {	
	    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("login");
	    	u = cliente.searchUserByCF("GRGMHL98M31C129G");		    	
	    	Mockito.when(mockedRequest.getParameter("codicefiscale")).thenReturn(u.getCfUtente().toUpperCase());
	        Mockito.when(mockedRequest.getParameter("cognome")).thenReturn(u.getCognome());
	        Mockito.when(mockedRequest.getParameter("nome")).thenReturn(u.getNome());
	        Mockito.when(mockedRequest.getParameter("email")).thenReturn(u.getEmail());
	        Mockito.when(mockedRequest.getParameter("password")).thenReturn(u.getPass());
	        Mockito.when(mockedRequest.getParameter("citta")).thenReturn(u.getCitta());
	        Mockito.when(mockedRequest.getParameter("via")).thenReturn(u.getVia());
	        String NCivico = String.valueOf(u.getNCivico());
	        Mockito.when(mockedRequest.getParameter("ncivico")).thenReturn(NCivico);
	        String Cap = String.valueOf(u.getCap());
	        Mockito.when(mockedRequest.getParameter("cap")).thenReturn(Cap);
	        Mockito.when(mockedRequest.getRequestDispatcher(Mockito.anyString())).thenReturn(mockedDispatcher);
	        servlet.doGet(mockedRequest,mockedResponse);	    		       
	    }
	    
	    @Test
	    @Order(2)
	    void TC_INSERT_1() throws IOException, ServletException
	    {	
	    	Mockito.when(mockedRequest.getParameter("action")).thenReturn("insert");
	    	u = new UserBean();   	
	    	Mockito.when(mockedRequest.getParameter("codicefiscale")).thenReturn("CHRVCN81HL8452C");
	        Mockito.when(mockedRequest.getParameter("cognome")).thenReturn("VINCENZO");
	        Mockito.when(mockedRequest.getParameter("nome")).thenReturn("CHIERCHIA");
	        Mockito.when(mockedRequest.getParameter("email")).thenReturn("test@test.com");
	        Mockito.when(mockedRequest.getParameter("password")).thenReturn("test");
	        Mockito.when(mockedRequest.getParameter("citta")).thenReturn("napoli");
	        Mockito.when(mockedRequest.getParameter("via")).thenReturn("principe");
	        String NCivico = String.valueOf(1);
	        Mockito.when(mockedRequest.getParameter("ncivico")).thenReturn(NCivico);
	        String Cap = String.valueOf(80054);
	        Mockito.when(mockedRequest.getParameter("cap")).thenReturn(Cap);
	        Mockito.when(mockedRequest.getRequestDispatcher(Mockito.anyString())).thenReturn(mockedDispatcher);
	        servlet.doGet(mockedRequest,mockedResponse);		        
	    }
	    	    
	    
	 @AfterAll
	    void tearDown()
	    {
	        mockedRequest=null;
	        mockedResponse=null;
	        servlet=null;
	        mockedSession=null;
	        mockedDispatcher=null;
	    }

}