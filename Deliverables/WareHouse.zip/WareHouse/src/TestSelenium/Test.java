package TestSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\pc1\\Documents\\Selenium\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost/WareHouse/UsersOperations/UsersOperations.html");
		//driver.navigate().to("https://www.google.com/");
		WebElement txtbx_username = driver.findElement(By.name("Log-In"));
		
		txtbx_username.sendKeys("username");
		
		driver.findElement(By.name("email"));
		
	    driver.quit();
	    driver.close();
		
		
		
	}

}