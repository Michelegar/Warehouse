package servlet.admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import bean.UserBean;
import operations.Cliente;


@WebServlet(name="UserOperationsAdmin" ,urlPatterns="/UserOpAdmin")

public class UserOperationsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static String SAVE_DIR="";
	static Cliente model;


	public UserOperationsAdmin() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(String)request.getParameter("action");
		model= new Cliente();
		String numberPageString =(String)request.getParameter("numberPage");
		if(numberPageString==null||numberPageString==""){
			numberPageString="1";
		}

		int numberPage = Integer.parseInt(numberPageString);

		if(numberPage<1){
			numberPage=1;
		}

		/*Controllo lato admin*/
		if(action!=null){
			if(action.equalsIgnoreCase("showlist")){

				try {
					Collection<UserBean> collection= model.getUsers(numberPage);
					request.setAttribute("collection", collection);
				} catch (SQLException e1) {
					request.setAttribute("opfailed", e1);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorUserManagement.jsp");
					rd.forward(request, response);
					e1.printStackTrace();
				}

				RequestDispatcher rd= getServletContext().getRequestDispatcher("/userManagement.jsp");
				rd.forward(request, response);
			}  

			else if(action.equalsIgnoreCase("checkPassword")){
				String cf  = request.getParameter("cf");
				String pass1  = request.getParameter("pass1");
				String pass2 = request.getParameter("pass2");
				UserBean user = (UserBean) request.getSession().getAttribute("user");
				if(user.getRank().equalsIgnoreCase("Amministratore")) {
					if(pass1.equals(user.getPass())) {
						if(pass1.equals(pass2)) {
							try {
								model.deleteUser(cf);
								RequestDispatcher rd= getServletContext().getRequestDispatcher("/deleteUserCompleted.jsp");
								rd.forward(request, response);
							} catch (SQLException e) {
								e.printStackTrace();
								RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorDeleteUser.jsp");
								rd.forward(request, response);
							}
						}
						else {
							request.getSession().setAttribute("confermaPassErrata", true);
							RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorDeleteUser.jsp");
							rd.forward(request, response);
						}
					}
					else {
						request.getSession().setAttribute("PassErrata", true);
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorDeleteUser.jsp");
						rd.forward(request, response);
					}
				}
				else {
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/accessDenied.jsp");
					rd.forward(request, response);
				}


			} else if(action.equalsIgnoreCase("showlistbycodice")){
				String email=request.getParameter("email");
				Collection <UserBean> collection = new LinkedList<UserBean>();

				try {
					if(email != null){
						UserBean utente= model.searchUser(email);
						if(utente.getEmail()!="")	collection.add(utente);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				}
				request.setAttribute("collection", collection);
				RequestDispatcher rd= getServletContext().getRequestDispatcher("/userManagement.jsp");
				rd.forward(request, response);
			}

			else if(action.equalsIgnoreCase("redirectForUpdate")){
				/*Bisogna lavorare su un solo elemento quindi si fa il redirect su altra 
				 * pagina impostando quello che � l'oggetto nella sessione*/

				String cf= request.getParameter("cf");

				try {
					UserBean user = model.searchUser(cf);
					request.getSession().setAttribute("utente", user);
					/*Redirict alla pagina di modifica*/
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/updateUser.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {
					request.setAttribute("opfailed", e);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorUserUpdate.jsp");
					rd.forward(request, response);
					e.printStackTrace();
				}


			} else if(action.equalsIgnoreCase("update")){
				UserBean user = new UserBean();
				String cf = request.getParameter("cf");
				String rank=request.getParameter("rank");
				user.setCfUtente(cf);
				user.setRank(rank);

				try {
					model.updateUserRank(user);
					RequestDispatcher rd = request.getRequestDispatcher("/updateUserCompleted.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					RequestDispatcher rd = request.getRequestDispatcher("/errors/errorUpdateUser.jsp");
					rd.forward(request, response);
				}


			}


		}

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}


}
