-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `CF_CLIENTE` char(16) NOT NULL,
  `Nome` varchar(45) DEFAULT NULL,
  `Cognome` varchar(45) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Pass` varchar(20) NOT NULL,
  `Citta` varchar(35) DEFAULT NULL,
  `Via` varchar(45) DEFAULT NULL,
  `N_Civico` varchar(4) DEFAULT NULL,
  `CAP` char(5) DEFAULT NULL,
  `Rank` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`CF_CLIENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES ('CHRDRD81H15L845C','EDUARDO','CHIERCHIA','eduardo.chierchia@gmail.com','napoli','roma','alighieri','50','80050','Assistenza'),('CRCMG92C14C129G','CARMELA','GARGIULO','carmelagar.92@live.it','carmela','napoli','acton','14','80050','Operatore'),('GRGMHL98M31C129G','MICHELE','GARGIULO','mikigar.98@live.it','michele','pimonte','roma','8','80054','Amministratore');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversazione`
--

DROP TABLE IF EXISTS `conversazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversazione` (
  `id` int NOT NULL,
  `CODICE_TICKET` char(10) NOT NULL,
  `messaggi` varchar(999) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `CODICE_TICKET_idx` (`CODICE_TICKET`),
  CONSTRAINT `CODICE_TICKET` FOREIGN KEY (`CODICE_TICKET`) REFERENCES `ticket` (`CODICE_TICKET`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversazione`
--

LOCK TABLES `conversazione` WRITE;
/*!40000 ALTER TABLE `conversazione` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merce`
--

DROP TABLE IF EXISTS `merce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `merce` (
  `CODICE_MERCE` varchar(100) NOT NULL,
  `Marca` varchar(45) DEFAULT NULL,
  `Titolo` varchar(20) DEFAULT NULL,
  `Categoria` varchar(20) DEFAULT NULL,
  `Descrizione` varchar(150) DEFAULT NULL,
  `Costo` int DEFAULT NULL,
  `Immagine` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`CODICE_MERCE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merce`
--

LOCK TABLES `merce` WRITE;
/*!40000 ALTER TABLE `merce` DISABLE KEYS */;
INSERT INTO `merce` VALUES ('111','asus','geForce','PC & Laptop','Notebook i7 SSD 256 GB Ram 8 GB 15.6',990,'111'),('222','nikon','NIKON','Fotocamere','Sensore 21.3 Megapixel Memoria SD/SDHC/MMS - Filmati Full HD',980,'222'),('333','acer','ACER Swift','PC & Laptop','Vivobook SLIM SSD da 500 Gb Cpu Intel i7 4 Core 12Gb DDR4 Display da 15.6 FULL HD',1400,'333'),('444','samsung','SFE','Smartphone','Rete LTE 5G -  6Core - 256GB - Display 7.8 - Video 4k',560,'444'),('666','samsung','SLIGHT','Smartphone','Rete LTE 5G -  6Core - 256GB - Display 7.8 - Video 4k',690,'666'),('777','acer','Acer s20','PC & Laptop','Notebook i7 SSD 256 GB Ram 8 GB 15.6',990,'777'),('888','asus','Asus s4','PC & Laptop',' Notebook i7 SSD 256 GB Ram 8 GB 15.6',1200,'888'),('999','lumix','LUMIX','Fotocamere','Sensore 22.3 Megapixel Memoria SD/SDHC/MMS - Filmati Full HD',2000,'999'),('ip11ROSSO','apple','IPHONE 11 PRO','Smartphone','Rete LTE 4G   6Core  128GB  Display 6.8  Video 4k red',780,'ip11ROSSO'),('ip12BLUE','apple','IPHONE 12','Smartphone','Rete LTE 5G   6Core  256GB - Display 6.8 - Video 4k',900,'ip12BLUE'),('iphone11','apple','IPHONE 11','Smartphone','Rete LTE 4G -  6Core - 256GB - Display 6.0 - Video 4k - white',620,'iphone11'),('iphoneX','apple','IPHONE X','Smartphone','Rete LTE 4G -  6Core - 256GB - Display 5.8 - Video 4k',450,'iphoneX');
/*!40000 ALTER TABLE `merce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messaggio`
--

DROP TABLE IF EXISTS `messaggio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messaggio` (
  `MITTENTE` varchar(20) NOT NULL,
  `ID_CONVERSAZIONE` int NOT NULL,
  `Testo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`MITTENTE`),
  KEY `ID_CONVERSAZIONE_idx` (`ID_CONVERSAZIONE`),
  CONSTRAINT `ID_CONVERSAZIONE` FOREIGN KEY (`ID_CONVERSAZIONE`) REFERENCES `conversazione` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messaggio`
--

LOCK TABLES `messaggio` WRITE;
/*!40000 ALTER TABLE `messaggio` DISABLE KEYS */;
/*!40000 ALTER TABLE `messaggio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordine_cliente`
--

DROP TABLE IF EXISTS `ordine_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine_cliente` (
  `CODICE_ORDINE` int NOT NULL AUTO_INCREMENT,
  `DataOrdine` date DEFAULT NULL,
  `Mezzo` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `N_Merci` int DEFAULT NULL,
  `Totale` int DEFAULT NULL,
  `MetodoDiPagamento` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `N_Carta` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CF_CLIENTE` char(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Citta` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Via` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `N_Civico` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CAP` char(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Stato` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`CODICE_ORDINE`),
  KEY `CF_CLIENTE_idx` (`CF_CLIENTE`),
  CONSTRAINT `CF_CLIENTE` FOREIGN KEY (`CF_CLIENTE`) REFERENCES `cliente` (`CF_CLIENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordine_cliente`
--

LOCK TABLES `ordine_cliente` WRITE;
/*!40000 ALTER TABLE `ordine_cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordine_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `segnalazione`
--

DROP TABLE IF EXISTS `segnalazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `segnalazione` (
  `CODICE_SEGNALAZIONE` varchar(15) NOT NULL,
  `CODICE_ORDINE` int NOT NULL,
  `Email_Assistenza` varchar(50) NOT NULL,
  PRIMARY KEY (`CODICE_SEGNALAZIONE`),
  KEY `CODICE_ORDINE_idx` (`CODICE_ORDINE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `segnalazione`
--

LOCK TABLES `segnalazione` WRITE;
/*!40000 ALTER TABLE `segnalazione` DISABLE KEYS */;
/*!40000 ALTER TABLE `segnalazione` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `CODICE_TICKET` char(10) NOT NULL,
  `Titolo` varchar(45) DEFAULT NULL,
  `Descrizione` varchar(45) DEFAULT NULL,
  `Stato` varchar(45) DEFAULT NULL,
  `CODICE_ORDINE` int DEFAULT NULL,
  `CF_CLIENTE` char(16) DEFAULT NULL,
  PRIMARY KEY (`CODICE_TICKET`),
  KEY `CODICE_ORDINE_idx` (`CODICE_ORDINE`),
  CONSTRAINT `CODICE_ORDINE` FOREIGN KEY (`CODICE_ORDINE`) REFERENCES `ordine_cliente` (`CODICE_ORDINE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ecommerce'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-06 16:04:49
