package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;
import bean.TicketBean;
import operations.Ticket;

/**
 * Servlet implementation class OrdersOperations
 */
@WebServlet("/TicketOperations")
public class TicketOperations extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Ticket model = new Ticket();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TicketOperations() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		boolean userLog = (boolean) request.getSession().getAttribute("userlog");
	    String numberPageString =(String)request.getParameter("numberPage");
		if(numberPageString==null||numberPageString==""){
			numberPageString="1";
		}
		
		int numberPage = Integer.parseInt(numberPageString);

		if(userLog){
			if((action!= null)&&(!action.equals(""))){

				if(action.equalsIgnoreCase("insert")){			
					String titolo=request.getParameter("titolo");
					String descrizione=request.getParameter("descrizione");
					String stato="Aperto";
					int codiceOrdine=Integer.parseInt(request.getParameter("codice"));
					UserBean user=(UserBean) request.getSession().getAttribute("user");
					String cfCliente=user.getCfUtente();

					TicketBean newTicket = new TicketBean();
					newTicket.setTitolo(titolo);
					newTicket.setDescrizione(descrizione);
					newTicket.setStato(stato);
					newTicket.setCodiceOrdine(codiceOrdine);
					newTicket.setCodiceFiscale(cfCliente);

				
						try {
							model.insertNewticket(newTicket);
							RequestDispatcher rd=request.getRequestDispatcher("ticketCreated.jsp");  
							rd.forward(request,response);
						} catch (SQLException e) {
							request.setAttribute("opfailed", e);
							RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorTicketNotCreated.jsp");
							rd.forward(request, response);
							e.printStackTrace();
						}
					}

					
				
				else if(action.equalsIgnoreCase("searchOpenTicketsByUser")) {
					Collection<TicketBean>openTicketsByUser;
					UserBean user = (UserBean) request.getSession().getAttribute("user");
					try {
						openTicketsByUser=model.searchOpenTicketsByCf(user.getCfUtente(), numberPage);
						request.setAttribute("openTicketsByUser", openTicketsByUser);
						RequestDispatcher rd=request.getServletContext().getRequestDispatcher("/openTickets.jsp");  
						rd.forward(request,response);
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();	
					}
				}

				else if(action.equalsIgnoreCase("searchClosedTicketsByUser")){
					Collection<TicketBean> closedTicketsByUser;
					UserBean user = (UserBean) request.getSession().getAttribute("user");
					try {
						closedTicketsByUser=model.searchClosedTicketsByCf(user.getCfUtente(), numberPage);
						request.setAttribute("closedTicketsByUser", closedTicketsByUser);
						RequestDispatcher rd=request.getServletContext().getRequestDispatcher("/closedTickets.jsp");  
						rd.forward(request,response);
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();	
					}
				}

				else{
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
					rd.forward(request,response);
				}

			}
			else{
				// action � uguale a null oppure a ""
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
				rd.forward(request,response);
			}
		}

		else {
			// l' utente non � loggato non pu� utilizzare la servlet

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
