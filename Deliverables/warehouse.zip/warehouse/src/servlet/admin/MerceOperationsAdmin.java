package servlet.admin;

//import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.Part;

import bean.MerceBean;
import bean.UserBean;
import operations.Merce;
//import tool.ResizeUploadedImageAndWrite;


@WebServlet(name="MerceOperationsAdmin" ,urlPatterns="/MerceOpAdmin", 
initParams={@WebInitParam(name="file-upload", value="images")})
@MultipartConfig(fileSizeThreshold=1024*1024*2,maxFileSize=1024*1024*50, maxRequestSize=1024*1024*50)

public class MerceOperationsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static String SAVE_DIR="";
	static Merce model;


	public void init(){
		SAVE_DIR = getServletConfig().getInitParameter("file-upload");

	}

	public MerceOperationsAdmin() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=(String)request.getParameter("action");
		model= new Merce();
		String numberPageString =(String)request.getParameter("numberPage");
		if(numberPageString==null||numberPageString==""){
			numberPageString="1";
		}

		int numberPage = Integer.parseInt(numberPageString);

		if(numberPage<1){
			numberPage=1;
		}

		/*Controllo lato admin*/
		if(action!=null){
			if(action.equalsIgnoreCase("showlist")){

				try {
					Collection<MerceBean> collection= model.getAllMerce(null,numberPage);
					request.setAttribute("collection", collection);
				} catch (SQLException e1) {
					request.setAttribute("opfailed", e1);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/notSuccessful.jsp");
					rd.forward(request, response);
					e1.printStackTrace();
				}

				RequestDispatcher rd= getServletContext().getRequestDispatcher("/mercemanagement.jsp");
				rd.forward(request, response);


			} else if(action.equalsIgnoreCase("showlistbycodice")){
				String codice=request.getParameter("codicemerce");
				Collection <MerceBean> collection = new LinkedList<MerceBean>();

				try {
					if(codice != null){
						MerceBean merce= model.searchMerceByCodiceMerce(codice);
						if(merce.getCodiceMerce()!="")	collection.add(merce);
						else collection=null;
					}

					else {
						collection = model.getAllMerce(null,numberPage);
					}

				} catch (SQLException e) {
					e.printStackTrace();
				}
				request.setAttribute("collection", collection);
				RequestDispatcher rd= getServletContext().getRequestDispatcher("/mercemanagement.jsp");
				rd.forward(request, response);


			} else if(action.equalsIgnoreCase("insert")){

				MerceBean merce= new MerceBean();
				//				String finalStringPath = null;
				String codice=request.getParameter("codice");
				String marca=request.getParameter("marca");
				String prodotto= request.getParameter("prodotto");
				String categoria=request.getParameter("categoria");
				String descrizione=request.getParameter("descrizione");
				double costo=Double.parseDouble(request.getParameter("costo"));

				//				Part part = request.getPart("image");
				//				
				//			
				//				if(part!=null && part.getSize()!=0){
				//					String savePath=request.getServletContext().getRealPath("")+SAVE_DIR;
				//
				//					File fileSavePath= new File(savePath);
				//					if(!fileSavePath.exists()){
				//						fileSavePath.mkdirs();
				//					}
				//					String fileName = extractFileName(part); /*resistuisci il path completo dell'immagine*/
				//					fileName=fileName.substring(fileName.indexOf(File.separator,fileName.lastIndexOf(File.separator))+1, fileName.length());
				//					finalStringPath = savePath + File.separator + fileName;
				//
				//					ResizeUploadedImageAndWrite.resizeAndSave(part, finalStringPath);
				//				}

				merce.setCodiceMerce(codice);
				merce.setMarca(marca);
				merce.setTitolo(prodotto);
				merce.setCategoria(categoria);
				merce.setDescrizione(descrizione);
				merce.setCosto(costo);
				merce.setImmagine(codice);



				try {
					model.insertNewMerce(merce);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/insertMerceCompleted.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {
					request.getSession().setAttribute("opfailed",e);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorInsertMerce.jsp");
					rd.forward(request, response);
					e.printStackTrace();
				}
				/*aggiungere messagio di buona riuscita*/


			} else if(action.equalsIgnoreCase("delete")){
				String codiceMerce  = request.getParameter("CodiceMerce");

				try {
					model.deleteMerce(codiceMerce);

					RequestDispatcher rd= getServletContext().getRequestDispatcher("/ModCancMerce.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				
				
				else if(action.equalsIgnoreCase("checkPassword")){
					String pass1  = request.getParameter("pass1");
					String pass2 = request.getParameter("pass2");
					String codiceMerce= request.getParameter("codiceMerce");
					UserBean user = (UserBean) request.getSession().getAttribute("user");
					if(user.getRank().equalsIgnoreCase("Amministratore")) {
						if(pass1.equals(user.getPass())) {
							if(pass1.equals(pass2)) {
								try {
									model.deleteMerce(codiceMerce);
									RequestDispatcher rd= getServletContext().getRequestDispatcher("/deleteMerceCompleted.jsp");
									rd.forward(request, response);
								} catch (SQLException e) {
									e.printStackTrace();
									RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorDeleteMerce.jsp");
									rd.forward(request, response);
								}
							}
							else {
								request.getSession().setAttribute("confermaPassErrata", true);
								RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorDeleteMerce.jsp");
								rd.forward(request, response);
							}
						}
						else {
							request.getSession().setAttribute("PassErrata", true);
							RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorDeleteMerce.jsp");
							rd.forward(request, response);
						}
					}
					else {
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/accessDenied.jsp");
						rd.forward(request, response);
					}
					

			} else if(action.equalsIgnoreCase("redirectForUpdate")){
				/*Bisogna lavorare su un solo elemento quindi si fa il redirect su altra 
				 * pagina impostando quello che � l'oggetto nella sessione*/

				String codiceMerce= request.getParameter("CodiceMerce");

				try {
					MerceBean merce = model.searchMerceByCodiceMerce(codiceMerce);
					request.getSession().setAttribute("merce", merce);
					/*Redirict alla pagina di modifica*/
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/updateMerce.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {
					request.setAttribute("opfailed", e);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorMerceUpdate.jsp");
					rd.forward(request, response);
					e.printStackTrace();
				}


			} else if(action.equalsIgnoreCase("update")){
				//String finalStringPath = null;
				double costo=0.0;
				MerceBean merce = new MerceBean();
				//MerceBean oldMerce = (MerceBean)request.getSession().getAttribute("merce");
				String codiceMerce = request.getParameter("codice");
				String marca=request.getParameter("marca");
				String prodotto=request.getParameter("prodotto");
				String categoria=request.getParameter("categoria");
				String descrizione=request.getParameter("descrizione");
				if(request.getParameter("costo")!=null || !request.getParameter("costo").equals("")){
					//eccezione empty string senza questo controllo
					costo = Double.parseDouble(request.getParameter("costo"));
				}

				//					Part part = request.getPart("image");
				//										
				//					if(part!=null && part.getSize()!=0){
				//
				//						String savePath=request.getServletContext().getRealPath("")+SAVE_DIR;
				//
				//						File fileSavePath= new File(savePath);
				//						if(!fileSavePath.exists()){
				//							fileSavePath.mkdirs();
				//						}
				//						if(oldMerce.getImmagine()!=null){//potrebbe essere caricato un prodotto senza l'immagine
				//						String  deleteOldImage = oldMerce.getImmagine().substring(oldMerce.getImmagine().indexOf(File.separator,oldMerce.getImmagine().lastIndexOf(File.separator))+1, oldMerce.getImmagine().length());
				//							File oldImage = new File(deleteOldImage);
				//							if(oldImage.exists()){
				//								oldImage.delete();
				//							}
				//						}
				//						String fileName = extractFileName(part); /*resistuisci il path completo dell'immagine*/
				//						fileName = fileName.substring(fileName.indexOf(File.separator,fileName.lastIndexOf(File.separator))+1, fileName.length());
				//						finalStringPath = savePath + File.separator + fileName;
				//						System.out.println(finalStringPath);
				//						ResizeUploadedImageAndWrite.resizeAndSave(part,finalStringPath);
				//
				//					} else {
				//						System.out.println(finalStringPath);
				//						finalStringPath = oldMerce.getImmagine();
				//					}


				merce.setCodiceMerce(codiceMerce);
				merce.setMarca(marca);
				merce.setTitolo(prodotto);
				merce.setCategoria(categoria);
				merce.setDescrizione(descrizione);
				merce.setCosto(costo);
				merce.setImmagine(codiceMerce);

				try {
					model.updateMerce(merce);
					RequestDispatcher rd = request.getRequestDispatcher("/updateMerceCompleted.jsp");
					rd.forward(request, response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					RequestDispatcher rd = request.getRequestDispatcher("/errors/errorUpdateMerce.jsp");
					rd.forward(request, response);
				}

				
			}


		}

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

	//	private String extractFileName(Part part){
	//		
	//		String cd=	part.getHeader("content-disposition");
	//		String[]items=cd.split(";");
	//			
	//		for(String s: items){
	//			if(s.trim().startsWith("filename")){
	//				return s.substring(s.indexOf("=")+2,s.length()-1);
	//			}
	//		}
	//		return "";
	//	}

}
