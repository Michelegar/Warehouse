package servlet.operator;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.OrderBean;
import bean.TicketBean;
import operations.OrdineCliente;

/**
 * Servlet implementation class OrdersOperationsAdmin
 */
@SuppressWarnings("unused")
@WebServlet("/OrdersOperationsAdmin")
public class OrdersOperationsAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static OrdineCliente model;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrdersOperationsAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		model = new OrdineCliente();
		String action = request.getParameter("action");
		String numberPageString =(String)request.getParameter("numberPage");
		if(numberPageString==null||numberPageString==""){
			numberPageString="1";
		}
		
		int numberPage = Integer.parseInt(numberPageString);
		
		if(numberPage<1){
			numberPage=1;
		}
		boolean adminLog = (boolean) request.getSession().getAttribute("adminlog");
		boolean userLog = (boolean) request.getSession().getAttribute("userlog");
		
		if(userLog||adminLog){
			if((action!= null)&&(!action.equals(""))){
				
				if(action.equalsIgnoreCase("delete")){
					int code = Integer.parseInt(request.getParameter("codiceOrdine"));
					try {
						model.deleteOrder(code);
						RequestDispatcher rd=request.getServletContext().getRequestDispatcher("/AllOrders.jsp");  
						rd.forward(request,response);
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();	
					}
				}
				else if (action.equalsIgnoreCase("returnAll")){
					Collection<OrderBean> allOrders;
					try {
						allOrders=model.getAllOrders(numberPage);
						request.setAttribute("allOrders", allOrders);
						RequestDispatcher rd=request.getServletContext().getRequestDispatcher("/AllOrders.jsp");  
						rd.forward(request,response);
					} catch (SQLException e) {
						request.setAttribute("opfailed", e);
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/notSuccessful.jsp");
						rd.forward(request, response);
						e.printStackTrace();
					}
				}	
			}	
		}
		else {
			// l' utente non � loggato non pu� utilizzare la servlet
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
			rd.forward(request,response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
