package servlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;
import operations.Cliente;

/**
 * Servlet implementation class UsersOperations
 */
@WebServlet("/UsersOperations")
public class UsersOperations extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static Cliente model=new Cliente();
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UsersOperations() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");

		if((action!= null)&&(!action.equals(""))){
			if(action.equalsIgnoreCase("insert")){
				request.getSession().setAttribute("adminlog", false);
				request.getSession().setAttribute("userlog", false);
				request.getSession().setAttribute("operatorlog", false);
				request.getSession().setAttribute("assistenzalog", false);
				String codicefiscale=request.getParameter("codicefiscale");
				codicefiscale.toUpperCase();
				String nome=request.getParameter("nome");
				String cognome=request.getParameter("cognome");
				String email=request.getParameter("email");
				String password=request.getParameter("password");
				String citta=request.getParameter("citta");
				String via=request.getParameter("via");
				int ncivico=Integer.parseInt(request.getParameter("ncivico"));
				int cap=Integer.parseInt(request.getParameter("cap"));
				String rank=""+"Cliente";


				UserBean newUser= new UserBean();

				newUser.setCfUtente(codicefiscale.toUpperCase());
				newUser.setNome(nome);
				newUser.setCognome(cognome);
				newUser.setEmail(email);
				newUser.setPass(password);
				newUser.setCitta(citta);
				newUser.setVia(via);
				newUser.setCap(cap);
				newUser.setNCivico(ncivico);
				newUser.setRank(rank);

				try {
					model.insertUser(newUser);
					newUser=model.searchUser(codicefiscale.toUpperCase());
					request.getSession().setAttribute("user", newUser);
					request.getSession().setAttribute("userlog", false);
					//RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/successful.jsp");
					//dispatcher.forward(request, response);
					response.sendRedirect(request.getContextPath() + "/successful.jsp");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println(e);
					request.getSession().setAttribute("error",e);
					RequestDispatcher rd=request.getRequestDispatcher("/errors/errorRegistration.jsp");  
					rd.forward(request,response); 

				}
			}

			else if(action.equalsIgnoreCase("login")){	
				String email=request.getParameter("email");
				String password=request.getParameter("password");
				UserBean user = new UserBean();
				try {
					user=model.searchUser(email);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//se l'utente esiste... controllo se le password coincidono
				if(!(user.getCfUtente().equals("0000000000000000"))){
					if(user.getPass().equals(password)){
						request.getSession().setAttribute("user", user);
						request.getSession().setAttribute("userlog", true);

						//controllo se � amministratore
						if(user.getRank().equals("Amministratore")){
							request.getSession().setAttribute("adminlog", true);
						}
						else{
							request.getSession().setAttribute("adminlog", false);
						}
						
						//controllo se � operatore
						if(user.getRank().equals("Operatore")){
							request.getSession().setAttribute("operatorlog", true);
						}
						else{
							request.getSession().setAttribute("operatorlog", false);
						}
						
						//controllo se � assistenza
						if(user.getRank().equals("Assistenza")){
							request.getSession().setAttribute("assistenzalog", true);
						}
						else{
							request.getSession().setAttribute("assistenzalog", false);
						}
						
						RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");  
						rd.forward(request,response);
					}
					else{
						request.getSession().setAttribute("userlog", false);
						request.getSession().setAttribute("adminlog", false);		
						request.getSession().setAttribute("errPass", true);
						request.getSession().setAttribute("refresh", true);
						RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");  
						rd.forward(request,response);
					}
				}


				//nessun user con quel id trovato
				else{
					request.getSession().setAttribute("userlog", false);
					request.getSession().setAttribute("adminlog", false);
					request.getSession().setAttribute("operatorlog", false);
					request.getSession().setAttribute("assistenzalog", false);
					request.getSession().setAttribute("errUser", true);
					request.getSession().setAttribute("refresh", true);
					RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");  
					rd.forward(request,response); 
				}

			}

			else if (action.equalsIgnoreCase("delete")){
				boolean userlog = (Boolean) request.getSession().getAttribute("userlog");
				boolean adminlog = (Boolean) request.getSession().getAttribute("adminlog");
				UserBean user = (UserBean) request.getSession().getAttribute("user");
				if(adminlog==false){
					if(userlog==true){
						try {
							model.deleteUser(user.getEmail());
							request.getSession().setAttribute("userlog", false);
							request.getSession().setAttribute("adminlog", false);
							request.getSession().setAttribute("user", new UserBean());
							request.getSession().invalidate();
						} catch (SQLException e) {
							//cancellazione non riuscita
							RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
							rd.forward(request,response); 
							e.printStackTrace();
						}
					}
					else{
						RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
						rd.forward(request,response); 
					}
				}
				else{
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
					rd.forward(request,response); 
				}
			}
			else if (action.equalsIgnoreCase("logout")){

				request.getSession().setAttribute("user", new UserBean());
				request.getSession().setAttribute("userlog", false);
				request.getSession().setAttribute("adminlog", false);
				request.getSession().setAttribute("operatorlog", false);
				request.getSession().setAttribute("assistenzalog", false);
				request.getSession().invalidate();
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
				rd.forward(request,response); 

			}

			else if(action.equalsIgnoreCase("updatePassword")){
			
				UserBean user = (UserBean) request.getSession().getAttribute("user");

				String oldPassword=request.getParameter("oldPass");
				String newPassword=request.getParameter("newPass");
				String rePassword=request.getParameter("rePass");



				if(oldPassword!=null && oldPassword.equals(user.getPass())){
					if(newPassword!=null && newPassword.equals(rePassword)){
						user.setPass(newPassword);
						try {
							model.updateUserPass(user);				
							RequestDispatcher rd=request.getRequestDispatcher("updateSuccessful.jsp");  
							rd.forward(request,response);
						} catch (SQLException e) {
							request.setAttribute("opfailed", e);
							RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/updateNotSuccessful.jsp");
							rd.forward(request, response);
							e.printStackTrace();
						}
					}
					else {
						request.setAttribute("passNuovaErrata", Boolean.TRUE);
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/updateNotSuccessful.jsp");
						rd.forward(request, response);
					}
				}

				else if(oldPassword!=null && !(oldPassword.equals(user.getPass()))) {
					request.setAttribute("passErrata", Boolean.TRUE);
					RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/updateNotSuccessful.jsp");
					rd.forward(request, response);
				}

			}

			else if(action.equalsIgnoreCase("update")){
				boolean userlog = (Boolean) request.getSession().getAttribute("userlog");
				UserBean user = (UserBean) request.getSession().getAttribute("user");

				String citta=request.getParameter("citta");
				String via=request.getParameter("via");
				int cap=Integer.parseInt(request.getParameter("cap"));
				int ncivico=Integer.parseInt(request.getParameter("ncivico"));


				if(userlog==true){
					if(citta==null||citta.equals("")){citta=user.getCitta();}
					if(via==null||via.equals("")){via=user.getVia();}
					if(cap==0) {cap=user.getCap();}
					if(ncivico==0){ncivico=user.getNCivico();}

					user.setCitta(citta);
					user.setVia(via);
					user.setCap(cap);
					user.setNCivico(ncivico);


					try {
						model.updateUser(user);				
						RequestDispatcher rd=request.getRequestDispatcher("updateProfileSuccessful.jsp");  
						rd.forward(request,response);
					} catch (SQLException e) {
						request.setAttribute("opfailed", e);
						RequestDispatcher rd= getServletContext().getRequestDispatcher("/errors/errorProfileUpdate.jsp");
						rd.forward(request, response);
						e.printStackTrace();
					}
				}
				else{
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
					rd.forward(request,response);
				}
			}
			else{
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
				rd.forward(request,response);
			}
		}
		else{
			// action � uguale a null oppure a "" 
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");  
			rd.forward(request,response); 
		}
	}
}
