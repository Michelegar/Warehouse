package operations;

import java.sql.*;

import java.util.*;

import bean.MerceBean;
import servlet.DriverManagerConnectionPool;

public class Merce {

	private final static String TABLE_NAME="Merce";
	
		public synchronized void insertNewMerce(MerceBean merce)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			
			String sqlInsert="INSERT INTO "+TABLE_NAME+"(CODICE_MERCE, MARCA,TITOLO,CATEGORIA, DESCRIZIONE, COSTO, IMMAGINE)VALUES(?,?,?,?,?,?,?)";
			try{
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement=connection.prepareStatement(sqlInsert);
				preparedStatement.setString(1, merce.getCodiceMerce());
				preparedStatement.setString(2, merce.getMarca());
				preparedStatement.setString(3, merce.getTitolo());
				preparedStatement.setString(4, merce.getCategoria());
				preparedStatement.setString(5, merce.getDescrizione());
				preparedStatement.setDouble(6, merce.getCosto());
				preparedStatement.setString(7, merce.getImmagine());
				
				preparedStatement.executeUpdate();
				
				connection.commit();
			} finally {
				try{
					if(connection!=null){
						connection.close();
					}
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
		}
		
		public synchronized boolean deleteMerce(String codiceMerce)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			int rs=0;
			
			String deleteSQL="DELETE FROM "+TABLE_NAME+" WHERE CODICE_MERCE=?";
			
			try{
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement=connection.prepareStatement(deleteSQL);
				preparedStatement.setString(1, codiceMerce);
				rs=preparedStatement.executeUpdate();
				connection.commit();
			} finally {
				try{
					if(connection!=null){
						connection.close();
					}
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
				
			}
			
			return (rs!=0);
		}
		
		public synchronized void updateMerce(MerceBean merce)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			String updateSQL="UPDATE "+TABLE_NAME+" SET MARCA=?, TITOLO=?, CATEGORIA=?, DESCRIZIONE=?, COSTO=?, IMMAGINE=? WHERE CODICE_MERCE=?";
			try{
				connection=DriverManagerConnectionPool.getConnection();
				preparedStatement=connection.prepareStatement(updateSQL);
				preparedStatement.setString(1, merce.getMarca());
				preparedStatement.setString(2, merce.getTitolo());
				preparedStatement.setString(3, merce.getCategoria());
				preparedStatement.setString(4, merce.getDescrizione());
				preparedStatement.setDouble(5, merce.getCosto());
				preparedStatement.setString(6, merce.getImmagine());
				preparedStatement.setString(7, merce.getCodiceMerce());
				preparedStatement.executeUpdate();
				connection.commit();
			} finally {
				
				try{
					if(connection!=null){
						connection.close();
					}
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
			
		}
		
		public synchronized MerceBean searchMerceByCodiceMerce(String codiceMerce)throws SQLException{
			MerceBean merce = new MerceBean();
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs = null;
			String searchMerceSql = "SELECT * FROM "+TABLE_NAME+ " WHERE CODICE_MERCE = ? ";
			
			
			try{
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(searchMerceSql);
				preparedStatement.setString(1, codiceMerce);
				rs = preparedStatement.executeQuery();
				
				
				
				if(rs.next()){
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
				}
			
			} finally {
				try{
					if(connection!=null){
						connection.close();
					}
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
				
			}
			
			return merce;
		}
		
		
		
		
		
		
		public synchronized Collection<MerceBean> searchMerceByCategoria (String codice,int numberPage)throws SQLException{
			
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			ResultSet rs=null;
			String searchMerceSql="SELECT * FROM "+TABLE_NAME + " WHERE CATEGORIA=?";
			searchMerceSql+=" LIMIT "+ (6) +" OFFSET "+ ((numberPage*6)-6);
			Collection<MerceBean> merceList= new LinkedList<MerceBean>();
			MerceBean merce;
			
			
			try{
				connection=DriverManagerConnectionPool.getConnection();
				preparedStatement=connection.prepareStatement(searchMerceSql);
				preparedStatement.setString(1, codice);
					
				rs=preparedStatement.executeQuery();
				
				while(rs.next()){
					merce = new MerceBean();
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
					merceList.add(merce);
				}


			} finally{
				try{
					if(connection!=null){
						connection.close();
					}
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
			
			
			return merceList;
		}
		
		public synchronized Collection<MerceBean>  getAllMerce(String order,int numberPage)throws SQLException{
			
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			Collection<MerceBean> merceList = new LinkedList<MerceBean>();
			MerceBean merce;
			
			
			ResultSet rs=null;
			String getAllMerceSql="SELECT * FROM "+TABLE_NAME;
			
			if(order!=null){
				getAllMerceSql+="ORDER BY "+order;
			}
			
			
			getAllMerceSql+=" LIMIT "+ (6) +" OFFSET "+ ((numberPage*6)-6);
			
			
			try{
				connection=DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(getAllMerceSql);
			
				rs=preparedStatement.executeQuery();

				while(rs.next()){
					merce = new MerceBean();
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
					merceList.add(merce);
				}


			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}

			}
			return merceList;
		}
		
		
		public synchronized Collection<MerceBean> searchMerceByMarca(String marca, int numberPage)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			MerceBean merce;
			Collection<MerceBean> merceList = new LinkedList<MerceBean>();
			
			String selectSQL = "SELECT * FROM "+TABLE_NAME+" WHERE MARCA = ? ORDER BY CODICE_MERCE";
			selectSQL+=" LIMIT "+ (6) +" OFFSET "+ ((numberPage*6)-6);
			
			try {
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, marca );
				ResultSet rs = preparedStatement.executeQuery();

				while (rs.next()) {
					merce = new MerceBean();
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
					merceList.add(merce);
				}

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
		
			return merceList;
		}
		
		public synchronized Collection<MerceBean> searchMerceByTitolo(String titolo, int numberPage)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			MerceBean merce;
			Collection<MerceBean> merceList = new LinkedList<MerceBean>();
			
			String selectSQL = "SELECT * FROM "+TABLE_NAME+" WHERE TITOLO LIKE ? ORDER BY CODICE_MERCE";
			selectSQL+=" LIMIT "+ (6) +" OFFSET "+ ((numberPage*6)-6);
			
			try {
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, "%"+titolo+"%" );
				ResultSet rs = preparedStatement.executeQuery();

				while (rs.next()) {
					merce = new MerceBean();
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
					merceList.add(merce);
				}

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
		
			return merceList;
		}
		
		public synchronized Collection<MerceBean> searchMerceByCostoMax(double prezzo,int numberPage)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			MerceBean merce;
			Collection<MerceBean> merceList = new LinkedList<MerceBean>();
			
			String selectSQL = "SELECT * FROM "+TABLE_NAME+" WHERE COSTO < ? ORDER BY CODICE_MERCE";
			selectSQL+=" LIMIT "+ (6) +" OFFSET "+ ((numberPage*6)-6);
			try {
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDouble(1, (int) prezzo );
				ResultSet rs = preparedStatement.executeQuery();

				while (rs.next()) {
					merce = new MerceBean();
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
					merceList.add(merce);
				}

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}

			return merceList;
		}
		
		public synchronized Collection<MerceBean> searchMerceByCostoMin(double prezzo,int numberPage)throws SQLException{
			Connection connection = null;
			PreparedStatement preparedStatement = null;
			MerceBean merce ;
			Collection<MerceBean> merceList = new LinkedList<MerceBean>();
			
			String selectSQL = "SELECT * FROM "+TABLE_NAME+" WHERE COSTO > ? ORDER BY CODICE_MERCE";
			selectSQL+=" LIMIT "+ (6) +" OFFSET "+ ((numberPage*6)-6);
			try {
				connection = DriverManagerConnectionPool.getConnection();
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setDouble(1, prezzo );
				ResultSet rs = preparedStatement.executeQuery();

				while (rs.next()) {
					merce = new MerceBean();
					merce.setCodiceMerce(rs.getString("CODICE_MERCE"));
					merce.setMarca(rs.getString("MARCA"));
					merce.setTitolo(rs.getString("TITOLO"));
					merce.setCategoria(rs.getString("CATEGORIA"));
					merce.setDescrizione(rs.getString("DESCRIZIONE"));
					merce.setCosto(rs.getDouble("COSTO"));
					merce.setImmagine(rs.getString("IMMAGINE"));
					merceList.add(merce);
				}

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
			
			return merceList;
		}
}
