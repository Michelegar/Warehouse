package bean;

public class MerceBean {

	private String codiceMerce;
	private String marca;
	private String titolo;
	private String categoria;
	private String descrizione;
	private double costo;
	private String immagine;
	

	public MerceBean() {
		this.codiceMerce =""; /* 10 caratteri */
		this.marca = "";
		this.titolo="";
		this.categoria="";
		this.descrizione = "";
		this.costo = 0.0;
		this.immagine ="";
	}


	public String getCodiceMerce() {
		return codiceMerce;
	}


	public void setCodiceMerce(String codice) {
		this.codiceMerce = codice;
	}
	
	public String getTitolo() {
		return titolo;
	}


	public void setTitolo(String codice) {
		this.titolo = codice;
	}
	
	public String getCategoria() {
		return categoria;
	}


	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String titolo) {
		this.marca = titolo;
	}

	public String getDescrizione() {
		return descrizione;
	}


	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}


	public double getCosto() {
		return costo;
	}


	public void setCosto(double costo) {
		this.costo = costo;
	}


	public String getImmagine() {
		return immagine;
	}


	public void setImmagine(String immagine) {
		this.immagine = immagine;
	}


	@Override
	public String toString() {
		return "MerceBean [codice merce=" + codiceMerce + ", marca=" + marca+", categoria=" + categoria + ", descrizione=" + descrizione + ", costo=" + costo + ", codice magazzino="
				+ ", codice ordine="+ ", immagine=" + immagine + "]";
	}

	

}
